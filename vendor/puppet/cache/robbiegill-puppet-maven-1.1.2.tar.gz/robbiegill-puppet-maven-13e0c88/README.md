# Puppet Module for Maven

Installs maven.

## Usage

```puppet
require maven
```

## Required Puppet Modules

* `boxen`
* `java`

## Development

Write code. Run `script/cibuild` to test it. Check the `script`
directory for other useful tools.
